import unittest
from main_unittest import countc

class Testcountc(unittest.TestCase):
    def test_simple(self):
        s = 'zara'
        c = 'a'
        self.assertEqual(countc(s, c), 2)
        
    def test_longer(self):
        s = 'zara zara zara zara zara'
        c = 'a'
        self.assertEqual(countc(s, c), 10)
        
    def test_nothing(self):
        s = ''
        c = 'a'
        self.assertEqual(countc(s, c), 0)
        
    def test_non_existance(self):
        s = 'zara'
        c = 'x'
        self.assertEqual(countc(s, c), 0)
        
    def test_all(self):
        s ='xxxxxxx'
        c = 'x'
        self.assertEqual(countc(s, c), 7)
        
if __name__ == '__main__':
    unittest.main()