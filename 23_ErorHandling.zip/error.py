def divide(a, b):
    return a / b

while True:
    try:
        num1 = int(input("Enter first number: "))
        num2 = int(input("Enter second number: "))

        result = divide(num1, num2)
        print("Result:", result)
        break

    except ValueError:
        print("Invalid input! Please enter numbers only.")

    except ZeroDivisionError:
        print("Error! Cannot divide by zero.")

    finally:
        print("Program executed successfully!")