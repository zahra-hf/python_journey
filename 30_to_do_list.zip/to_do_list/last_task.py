import csv


class Task:
    def __init__(self, name, description, priority):
        self.name = name
        self.description = description
        self.priority = priority

    def to_dict(self):
        return {
            "name": self.name,
            "description": self.description,
            "priority": self.priority
        }


class ToDoList:
    def __init__(self, filename="tasks.csv"):
        self.tasks = []
        self.filename = filename
        self.load_tasks()

    def add_task(self, task):
        self.tasks.append(task)
        self.save_tasks()
        print("Task added successfully.")

    def remove_task(self, name):
        for task in self.tasks:
            if task.name == name:
                self.tasks.remove(task)
                self.save_tasks()
                print("Task removed successfully.")
                return

        print("Task not found.")

    def show_tasks(self):
        if not self.tasks:
            print("No tasks available.")
            return

        for index, task in enumerate(self.tasks, start=1):
            print(f"{index}. {task.name}")
            print(f"   Description: {task.description}")
            print(f"   Priority: {task.priority}")
            print("----------------------")

    def save_tasks(self):
        with open(self.filename, "w", newline="") as file:
            writer = csv.DictWriter(
                file,
                fieldnames=["name", "description", "priority"]
            )

            writer.writeheader()

            for task in self.tasks:
                writer.writerow(task.to_dict())

    def load_tasks(self):
        try:
            with open(self.filename, "r") as file:
                reader = csv.DictReader(file)

                for row in reader:
                    task = Task(
                        row["name"],
                        row["description"],
                        row["priority"]
                    )

                    self.tasks.append(task)

        except FileNotFoundError:
            pass


def main():
    todo = ToDoList()

    while True:
        print("\n--- To-Do List Menu ---")
        print("1. Add Task")
        print("2. Remove Task")
        print("3. Show Tasks")
        print("4. Exit")

        choice = input("Choose an option: ")

        if choice == "1":
            name = input("Task name: ")
            description = input("Description: ")
            priority = input("Priority (High/Medium/Low): ")

            task = Task(name, description, priority)
            todo.add_task(task)

        elif choice == "2":
            name = input("Enter task name to remove: ")
            todo.remove_task(name)

        elif choice == "3":
            todo.show_tasks()

        elif choice == "4":
            print("Goodbye!")
            break

        else:
            print("Invalid option.")


if __name__ == "__main__":
    main()