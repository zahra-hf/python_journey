import csv

input_file = '1741502118270796.csv'
output_file = 'processed_products.csv'

with open(input_file, mode='r', encoding='utf-8') as infile:
    reader = csv.reader(infile)
    header = next(reader)
    
    # Add new column name to header
    header.append('Total Price')
    
    rows = []
    for row in reader:
        product_name = row[0]
        price = float(row[1])
        quantity = int(row[2])
        
        # Calculate total price
        total_price = price * quantity
        
        row.append(total_price)
        rows.append(row)

# Write to new CSV file
with open(output_file, mode='w', newline='', encoding='utf-8') as outfile:
    writer = csv.writer(outfile)
    writer.writerow(header)
    writer.writerows(rows)

print("File processed and saved successfully!")
