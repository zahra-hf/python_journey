from mylibrary.library import Library

library = Library()

if __name__ == "__main__":

    while True:

        print("\nLibrary Management System")
        print("1. Add Book")
        print("2. Remove Book")
        print("3. Search Book")
        print("4. Show Books")
        print("5. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            title = input("Enter book title: ")
            author = input("Enter author name: ")
            library.add_book(title, author)

        elif choice == "2":
            title = input("Enter book title: ")
            library.remove_book(title)

        elif choice == "3":
            title = input("Enter book title: ")
            library.search_book(title)

        elif choice == "4":
            library.show_books()

        elif choice == "5":
            print("Goodbye!")
            break

        else:
            print("Invalid choice.")