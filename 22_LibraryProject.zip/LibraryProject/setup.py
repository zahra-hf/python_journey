from setuptools import setup, find_packages

setup(
    name="mylibrary",
    version="1.0.0",
    author="Your Name",
    description="A simple library management system",
    packages=find_packages(),
)