class Library:

    def __init__(self):
        self.books = []

    def add_book(self, title, author):
        self.books.append({"title": title, "author": author})
        print("Book added successfully.")

    def remove_book(self, title):
        for book in self.books:
            if book["title"] == title:
                self.books.remove(book)
                print("Book removed successfully.")
                return
        print("Book not found.")

    def search_book(self, title):
        for book in self.books:
            if book["title"] == title:
                print(f'Title: {book["title"]}, Author: {book["author"]}')
                return
        print("Book not found.")

    def show_books(self):
        if not self.books:
            print("No books in the library.")
        else:
            for book in self.books:
                print(f'{book["title"]} - {book["author"]}')